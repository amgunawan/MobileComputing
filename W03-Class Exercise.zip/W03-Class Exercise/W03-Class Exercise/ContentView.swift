//
//  ContentView.swift
//  W03-Class Practice
//
//  Created by student on 25/09/25.
//

import SwiftUI

// software arsitektur SwiftUI: MVVM (Model View ViewModel)
// controller bisa dimasukkan di Model atau View
struct ContentView: View { // struct: immutable
    // @State: property wrapper (ketika value variabel berubah, maka generate ulang view nya)
    // variabel yang di set bukan @State, variabel menjadi immutable (tidak bisa berubah) dan value nya fix
    // @State akan menyimpan value number. Jika diubah valuenya, value yang berubah akan ditampilkan pada view
    @State private var number = 0
    
    @State private var count = 0
    @State private var name = ""
    
    // variabel baru untuk passing variabel count di CounterView (source of truth)
    @State private var totalCount = 0
    
    var body: some View {
        NavigationStack {
            VStack (spacing: 20){
                Text("🏡 Home Screen")
                    .font(.largeTitle)
                
                NavigationLink("Go to Details") {
                    DetailScreen()
                }
                NavigationLink("Show Items") {
                    ItemScreen()
                }
            }
        }
        
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .badge("3")
            
            SearchView()
                .tabItem {
                    Label("Search", systemImage: "magnifyingglass")
                }
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.circle")
                }
        }
        
        VStack {
            Text("Parent View")
                .font(.largeTitle)
            
            Text("Total Count: \(totalCount)")
                .font(.title2)
                .padding()
            
            // memanggil view yang lain
            // @State atau @Binding harus dipassing & dipanggil
            CounterView(count: $totalCount)
            
            Spacer()
            
            Button("Add") {
                number += 1
            }
            
            Text("Hello, world! \(number)")
                .padding(.bottom, 20)
            
            Text("Count: \(count)")
                .font(.largeTitle)
            
            Text("Nama: \(name)")
            
            TextField("Fill Name", text: $name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
            
            HStack {
                Button("-") {
                    count -= 1
                }
                
                Button("+") {
                    count += 1
                }
            }
        }
        .padding()
        .background(.green.opacity(0.6))
    }
}

#Preview {
    ContentView()
}
