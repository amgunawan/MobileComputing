//
//  W03_Class_ExerciseApp.swift
//  W03-Class Exercise
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_Class_ExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
