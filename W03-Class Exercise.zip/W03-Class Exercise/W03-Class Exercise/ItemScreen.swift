//
//  ItemScreen.swift
//  W03-Class Exercise
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ItemScreen: View {
    let items = ["Tomato", "Papaya", "Pineapple"]
    var body: some View {
        List(items, id: \.self) {
            item in NavigationLink(destination: ItemDetailScreen(item: item)) {
                Text(item)
            }
        }
        .navigationTitle("Items")
    }
}

#Preview {
    ItemScreen()
}
