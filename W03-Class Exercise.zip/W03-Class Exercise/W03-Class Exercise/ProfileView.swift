//
//  HomeView.swift
//  W03-Class Practice
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack {
            Text("👋 Profile!")
                .font(.largeTitle)
        }
    }
}

#Preview {
    HomeView()
}
