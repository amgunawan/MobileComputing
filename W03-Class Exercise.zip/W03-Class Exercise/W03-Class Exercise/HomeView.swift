//
//  HomeView.swift
//  W03-Class Practice
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct HomeView: View {
    @State private var myText = ""
    
    var body: some View {
        Form {
            VStack {
                Text("🏡 Home!")
                    .font(.largeTitle)
            }
        }
        .padding()
        .background(.yellow.opacity(0.4))
        .scrollContentBackground(.hidden)
    }
}

#Preview {
    HomeView()
}
