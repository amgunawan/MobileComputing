//
//  ItemDetailScreen.swift
//  W03-Class Exercise
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ItemDetailScreen: View {
    let item: String
    
    var body: some View {
        VStack {
            Text("🍇 Welcome to Item Detail! 🥑")
                .font(.title)
            Text("You Selected: \(item)")
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}
