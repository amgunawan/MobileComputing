//
//  W02_Take_HomeApp.swift
//  W02-Take Home
//
//  Created by Angela on 18/09/25.
//

import SwiftUI

@main
struct W02_Take_HomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
