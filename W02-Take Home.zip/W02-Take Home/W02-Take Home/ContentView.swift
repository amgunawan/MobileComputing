//
//  ContentView.swift
//  W02-Take Home
//
//  Created by Angela on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    // deklarasi variabel
    @State private var newTask = ""
    
    let tasks = ["Hunt's Algorithm", "Pre-Test Quiz", "Discussion & Reflection Task", "Take Home W2"]
    let courses = ["Data Mining", "IS Security & Governance", "IT Service Management", "Mobile Computing"]
    let deadlines = ["22/09/25", "23/09/25", "15/09/25", "25/09/25"]
    
    @State private var isOn = [false, false, true, false]
    
    var body: some View {
        VStack {
            HStack {
                Image(systemName: "list.bullet")
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(.primary, Color.accentColor)
                    .font(.title)
                
                Text("To Do List")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.accentColor)
                
                Spacer()
            }
            .padding(.leading, 20)
            
            HStack {
                // Component 1
                TextField("Enter new task", text: $newTask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                // Component 2
                Button(action: {
                    print("Add task: \(newTask)")
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                        .foregroundColor(.accentColor)
                }
            }
            .padding(.horizontal)
            .padding(.bottom, 10)
            
            // Component 3
            List(tasks.indices, id: \.self) { index in
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(tasks[index])
                            .font(.headline)
                        Text(courses[index])
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Text("Deadline: \(deadlines[index])")
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                    Spacer()
                    // Component 4
                    Toggle("", isOn: $isOn[index])
                        .labelsHidden()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
