//
//  W01_Class_PracticeApp.swift
//  W01-Class Practice
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_Class_PracticeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
