//
//  ContentView.swift
//  W01-Class Practice
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct ContentView: View{
    var body: some View {
        VStack(spacing: 15) {
            Image("My Photo")
                .resizable()
                .scaledToFit()
                .font(.system(size: 100))
                .clipShape(Circle())
                .overlay(content: {
                    Circle().strokeBorder(.black, lineWidth: 1)
                })
                .padding(.top, 25)
                .padding(.bottom, 50)
            
            let name = "Angela"
            let age = 20
            
            Text("Hi!, I'm \(name)")
                .font(.title)
                .fontWeight(.bold)
                .background(.blue)
                .foregroundColor(.white)
            
            Text("My age is \(age)")
                .font(.title2)
                .fontWeight(.medium)
                .background(.black)
                .foregroundStyle(LinearGradient(colors: [.yellow, .pink], startPoint: .topLeading, endPoint: .bottomTrailing))
            
            Text("😍❤️👋")
                .font(.title3)
                .background(.purple)
                .padding(.top, 25)
        
            // spacer: mengisi ruang kosong di bawah konten, sehingga isi VStack terdorong ke atas
            Spacer()
        }
    }
}

#Preview {
    ContentView()
}
