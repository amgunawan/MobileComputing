//
//  W01_Class_PracticeTests.swift
//  W01-Class PracticeTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_Class_Practice

struct W01_Class_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
