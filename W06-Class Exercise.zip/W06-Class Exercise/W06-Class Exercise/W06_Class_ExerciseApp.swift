//
//  W06_Class_ExerciseApp.swift
//  W06-Class Exercise
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

@main
struct W06_Class_ExerciseApp: App {
    let persistence = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            let vm = CoreDataStudentVM(context: persistence.container.viewContext)
            CoreDataStudentView(vm: vm)
        }
    }
}
