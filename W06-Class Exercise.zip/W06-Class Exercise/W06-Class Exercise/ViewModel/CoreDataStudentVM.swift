//
//  CoreDataStudentVM.swift
//  W06-Class Exercise
//
//  Created by student on 16/10/25.
//

import Foundation
import CoreData
import Observation

@Observable
@MainActor
final class CoreDataStudentVM {
    private let context: NSManagedObjectContext
    
    var students: [StudentEntity] = []
    
    init(context: NSManagedObjectContext) {
        self.context = context
        fetch()
    }
    
    // function untuk menarik data dari CoreData
    func fetch() {
        let request: NSFetchRequest<StudentEntity> = StudentEntity.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        do {
            students = try context.fetch(request)
        }
        catch {
            print("Fetch Error: \(error)")
        }
    }
    
    // function untuk menambah value di entity
    func add(name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        // StudentEntity refer pada Data Model
        let newStudent = StudentEntity(context: context)
        newStudent.name = trimmed
        newStudent.isFavorite = false
        saveAndRefresh()
    }
    
    func toggleFavorite(_ newStudent: StudentEntity) {
        newStudent.isFavorite.toggle()
        saveAndRefresh()
    }
    
    func delete(at offsets: IndexSet) {
        for i in offsets {
            context.delete(students[i])
        }
        saveAndRefresh()
    }
    
    // function untuk menyimpan ke Core Data jika berhasil (ada perubahan) dan rollback jika gagal
    // setelah selesai save, akan menarik data lagi dari Core Data
    // private karena tidak boleh terjadi perubahan data di dalam function
    private func saveAndRefresh() {
        do {
            try context.save()
        }
        catch {
            print("Save error: \(error)")
            context.rollback()
        }
        fetch()
    }
}
