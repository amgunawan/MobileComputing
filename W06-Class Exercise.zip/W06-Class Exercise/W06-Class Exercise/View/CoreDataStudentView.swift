//
//  CoreDataStudentView.swift
//  W06-Class Exercise
//
//  Created by student on 16/10/25.
//

import SwiftUI
import CoreData

struct CoreDataStudentView: View {
    var vm: CoreDataStudentVM
    
    @State private var newName: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    TextField("Enter student name", text: $newName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    // memasukkan student name ke Core Data
                    Button("Add") {
                        vm.add(name: newName)
                        newName = ""
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(.horizontal)
                
                // munculkan list nama student, jika Core Data kosong tidak muncul
                List {
                    ForEach(vm.students) { student in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(student.name ?? "(no name)")
                                    .font(.headline)
                                if (student.isFavorite) {
                                    Text("🤩 Favorite")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }
                            
                            Spacer()
                            
                            Button {
                                vm.toggleFavorite(student)
                            }
                            label: {
                                Image(systemName: student.isFavorite ? "heart.fill" : "heart")
                                    .foregroundColor(.red)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .onDelete(perform: vm.delete)
                }
                .listStyle(.insetGrouped)
            }
            .navigationTitle("Student Core Data")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    EditButton()
                }
            }
        }
    }
}

#Preview {
    let pc = PersistenceController.shared
    CoreDataStudentView(vm: CoreDataStudentVM(context: pc.container.viewContext))
}
