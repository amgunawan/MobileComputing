//
//  ContentView.swift
//  W06-Class Exercise
//
//  Created by student on 16/10/25.
//

import SwiftUI

// enum bisa ditulis di luar struct
enum LoadingState {
    case idle
    case loading
    case success(data: String)
    case error(message: String)
}

struct ContentView: View {
    // deklarasi array
    @State private var fruits: [String] = ["Apple", "Pear", "Durian"]
    
    // deklarasi dictionary: key & value
    @State private var scores: [String: Int] = [
        "Anne": 90,
        "Paul": 80,
        "David": 70
    ]
    
    @State private var studentName: String = ""
    
    // class
    @Observable
    class Counter {
        var count: Int = 0
        
        func increment() {
            count += 1
        }
        
        func decrement() {
            count -= 1
        }
    }
    
    @State private var counterA = Counter()
    // counterB adalah opsional dan nilai dasarnya adalah nil
    @State private var counterB: Counter? = nil
    
    // set: tidak memiliki urutan index (unordered items) dan tidak bisa duplikat item
    // set bisa digunakan untuk pembuatan kategori
    @State private var programmingLanguage: Set<String> = ["Swift", "JavaScript", "Python"]
    
    @State private var newLanguage: String = ""
    
    // tuple
    // cenderung digunakan untuk menampung tipe variabel yang sama
    // biasanya difungsikan untuk membawa paket informasi menjadi 1
    // bisa menerima value duplikat, namun urutan tidak bisa berubah
    // tuple biasanya digunakan untuk data-data yang kecil
    // bentuk tuple umumnya let, bukan var
    @State private var point: (x: Int, y: Int) = (x: 0, y: 0)
    
    // enum
    enum Grade: String, CaseIterable {
        case A, B, C, D, E
        
        var color: Color {
            switch self {
            case .A: return .green
            case .B: return .yellow
            case .C: return .orange
            case .D: return .red
            case .E: return .blue
            }
        }
    }
    
    @State private var grade: Grade = .A
    
    // contoh penggunaan enum
    enum APIResponse {
        case success(message: String)
        case failure(errorCode: Int, reason: String)
    }
    
    let response1 = APIResponse.success(message: "Data loaded!")
    
    @State private var state: LoadingState = .idle
    
    var body: some View {
        ScrollView {
            Text("Array of Fruits")
                .font(.largeTitle)
            
            HStack {
                ForEach(fruits, id:\.self) { fruit in
                    Text(fruit)
                        .padding(10)
                        .background(.orange.opacity(0.3))
                        .clipShape(Capsule())
                }
            }
            
            HStack {
                Button("Add Fruit") {
                    fruits.append("Banana")
                }
                .buttonStyle(.borderedProminent)
                
                Button("Remove Last") {
                    if !fruits.isEmpty {
                        fruits.removeLast(1)
                    }
                }
                .buttonStyle(.bordered)
            }
            .padding(.bottom)
            
            Text("Dictionary Explanation")
                .font(.largeTitle)
            VStack {
                // < ascending
                // > descending
                ForEach(scores.sorted(by: {$0.key < $1.key}), id:\.key) { name, score in
                    HStack {
                        Text(name)
                        Spacer()
                        Text("\(score)")
                            .bold()
                    }
                }
            }
            .padding(.bottom)
            
            VStack {
                // meningkatkan nilai dari score
                Button("Increase Anne's Score") {
                    scores["Anne", default: 0] += 5
                }
                .buttonStyle(.borderedProminent)
                
                Button("Increase Sean's Score") {
                    scores["Sean", default: 0] += 5
                }
                .buttonStyle(.borderedProminent)
                
                // delete semua value di dictionary
                Button("Delete All") {
                    if !scores.isEmpty {
                        scores.removeAll()
                    }
                }
                .padding(.bottom)
                
                // menambah nama student sesuai input textfield
                TextField("New Student Name", text: $studentName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button("Add Student") {
                    if !studentName.isEmpty {
                        scores[studentName] = 100
                        studentName = ""
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.bottom)
            
            // button counter A
            HStack {
                Button("-") {
                    counterA.decrement()
                }
                
                Text("Counter A: \(counterA.count)")
                
                Button("+") {
                    counterA.increment()
                }
            }
            
            // jika nilainya nil, maka default value = 5
            Text("Counter B: \(counterB?.count ?? 5)")
                .foregroundStyle(counterB == nil ? .red : .primary)
            
            Button(counterB == nil ? "Clone A to B" : "Unlink B") {
                if counterB == nil {
                    counterB = counterA
                }
                else {
                    counterB = nil
                }
            }
            .buttonStyle(.bordered)
            .padding(.bottom)
            
            Text("Set")
                .font(.largeTitle)
            
            HStack {
                ForEach(Array(programmingLanguage), id: \.self) { language in
                    Text(language)
                        .padding(5)
                        .background(.green)
                        .clipShape(Capsule())
                }
            }
            
            HStack {
                TextField("Enter new language", text: $newLanguage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 200)
                
                Button("Add") {
                    if !newLanguage.isEmpty {
                        programmingLanguage.insert(newLanguage)
                        newLanguage = ""
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.bottom)
            
            Text("Tuple")
                .font(.largeTitle)
            
            Text("Nilai sekarang XY: \(point.x), \(point.y)")
            
            HStack {
                Button("Kanan 10 langkah") {
                    point.x += 10
                }
                .buttonStyle(.borderedProminent)
                
                Button("Kebawah 10 langkah") {
                    point.y -= 10
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.bottom)
            
            Picker("Select Grade", selection: $grade) {
                ForEach(Grade.allCases, id: \.self) { g in
                    Text(g.rawValue)
                }
            }
            .pickerStyle(.segmented)
            
            Text("Your Grade: \(grade.rawValue)")
                .font(.largeTitle)
                .bold()
                .foregroundColor(grade.color)
                .padding(.bottom)
            
            Group {
                switch state {
                case .idle:
                    Text("Tap to start loading")
                case .loading:
                    ProgressView("Loading...")
                case .success(let data):
                    Text("Loaded: \(data)")
                        .foregroundColor(.green)
                case .error(message: let msg):
                    Text("Error: \(msg)")
                        .foregroundColor(.red)
                }
            }
            
            HStack {
                Button("Start") {
                    state = .loading
                }
                
                Button("Success") {
                    state = .success(data: "KTP mu berhasil diupload!")
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
