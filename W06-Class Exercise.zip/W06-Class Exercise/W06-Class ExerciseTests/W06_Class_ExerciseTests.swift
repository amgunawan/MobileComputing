//
//  W06_Class_ExerciseTests.swift
//  W06-Class ExerciseTests
//
//  Created by student on 16/10/25.
//

import Testing
@testable import W06_Class_Exercise

struct W06_Class_ExerciseTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
