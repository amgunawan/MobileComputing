//
//  HomeView.swift
//  W03-Take Home
//
//  Created by Angela on 25/09/25.
//

import SwiftUI

struct HomeView: View {
    @State private var search : String = ""
    
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground)
                .ignoresSafeArea(edges: .top)
            
            ScrollView {
                VStack {
                    HStack {
                        VStack (alignment: .leading) {
                            Text("Good Morning,")
                                .font(.system(.title2, design: .serif))
                            Text("Mikaela")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        }
                        
                        Spacer()
                        
                        Circle()
                            .fill(Color.pink.gradient)
                            .frame(width: 60, height: 60)
                            .overlay(
                        Image(systemName: "person.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 25))
                        )
                    }
                    
                    TextField("Search", text: $search)
                        .textFieldStyle(.roundedBorder)
                        .padding(.bottom, 20)
                    
                    VStack (spacing: 20) {
                        Text("Today's Goal")
                            .font(.title)
                            .foregroundStyle(.white)
                            .fontWeight(.bold)
                            .padding(.top, 10)
                        
                        HStack (spacing: 20) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.ultraThinMaterial)
                                    .opacity(0.5)
                                    .frame(width: 150, height: 175)
                                
                                VStack {
                                    Image(systemName: "figure.run")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 75, height: 75)
                                        .foregroundStyle(.white)
                                        .padding(.bottom, 5)
                                    
                                    Text("4 Miles")
                                        .font(.title2)
                                        .foregroundStyle(.white)
                                        .fontWeight(.bold)
                                    
                                    Text("@Thames Route")
                                        .font(.system(.footnote, design: .serif))
                                        .foregroundStyle(.white)
                                }
                            }
                            
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.ultraThinMaterial)
                                    .opacity(0.5)
                                    .frame(width: 150, height: 175)
                                
                                VStack {
                                    Image(systemName: "sailboat.fill")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 75, height: 75)
                                        .foregroundStyle(.white)
                                        .padding(.bottom, 5)
                                    
                                    Text("2 Miles")
                                        .font(.title2)
                                        .foregroundStyle(.white)
                                        .fontWeight(.bold)
                                    
                                    Text("@River Lea")
                                        .font(.system(.footnote, design: .serif))
                                        .foregroundStyle(.white)
                                }
                                .padding()
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        LinearGradient(colors: [.blue, .red], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .cornerRadius(20)
                    
                    VStack (spacing: 20) {
                        HStack (spacing: 20) {
                            ZStack(alignment: .topLeading) {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.white)
                                    .frame(height: 100)
                                
                                Image(systemName: "heart.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.purple, .blue],
                                            startPoint: .topTrailing,
                                            endPoint: .bottomLeading
                                        )
                                    )
                                    .padding(.top, 15)
                                    .padding(.leading, 15)
                                
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Text("68 Bpm")
                                            .font(.title2)
                                            .fontWeight(.medium)
                                            .foregroundStyle(.black)
                                            .padding(.bottom, 15)
                                            .padding(.trailing, 15)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 100)
                            .cornerRadius(20)
                            
                            ZStack(alignment: .topLeading) {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.white)
                                    .frame(height: 100)
                                
                                Image(systemName: "flame.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.orange.opacity(0.8), .red],
                                            startPoint: .topTrailing,
                                            endPoint: .bottomLeading
                                        )
                                    )
                                    .padding(.top, 15)
                                    .padding(.leading, 15)
                                
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Text("0 Kcal")
                                            .font(.title2)
                                            .fontWeight(.medium)
                                            .foregroundStyle(.black)
                                            .padding(.bottom, 15)
                                            .padding(.trailing, 15)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 100)
                            .cornerRadius(20)
                        }
                        
                        HStack (spacing: 20) {
                            ZStack(alignment: .topLeading) {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.white)
                                    .frame(height: 100)
                                
                                Image(systemName: "scalemass.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.green, .blue],
                                            startPoint: .topTrailing,
                                            endPoint: .bottomLeading
                                        )
                                    )
                                    .padding(.top, 15)
                                    .padding(.leading, 15)
                                
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Text("72 Kg")
                                            .font(.title2)
                                            .fontWeight(.medium)
                                            .foregroundStyle(.black)
                                            .padding(.bottom, 15)
                                            .padding(.trailing, 15)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 100)
                            .cornerRadius(20)
                            
                            ZStack(alignment: .topLeading) {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.white)
                                    .frame(height: 100)
                                
                                Image(systemName: "bed.double.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(
                                        LinearGradient(
                                            colors: [.blue, .green],
                                            startPoint: .topTrailing,
                                            endPoint: .bottomLeading
                                        )
                                    )
                                    .padding(.top, 15)
                                    .padding(.leading, 15)
                                
                                VStack {
                                    Spacer()
                                    HStack {
                                        Spacer()
                                        Text("6.2 Hr")
                                            .font(.title2)
                                            .fontWeight(.medium)
                                            .foregroundStyle(.black)
                                            .padding(.bottom, 15)
                                            .padding(.trailing, 15)
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 100)
                            .cornerRadius(20)
                        }
                    }
                    .padding(.top, 20)
                }
                .padding()
                .padding(.horizontal)
            }
        }
    }
}

#Preview {
    HomeView()
}
