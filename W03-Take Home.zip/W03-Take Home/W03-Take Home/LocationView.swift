//
//  LocationView.swift
//  W03-Take Home
//
//  Created by Angela on 25/09/25.
//

import SwiftUI

struct LocationView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    LocationView()
}
