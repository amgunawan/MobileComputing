//
//  W03_Take_HomeApp.swift
//  W03-Take Home
//
//  Created by Angela on 25/09/25.
//

import SwiftUI

@main
struct W03_Take_HomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
