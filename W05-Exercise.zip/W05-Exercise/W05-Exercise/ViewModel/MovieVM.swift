//
//  MovieVM.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import Foundation
import Observation
import SwiftUI

@Observable
final class MovieVM {
    var movies: [Movie] = []
    private let key = "movies.store.v1"
    
    // ketika view model pertama kali dipanggil, pertama kali akan menjalankan load()
    init() {
        load()
    }
    
    func toggleFavorite(_ movie: Movie) {
        if let i = movies.firstIndex(where: { $0.id == movie.id }) {
            movies[i].isFavorite.toggle()
        }
    }
    
    func addMovie(title: String, genre: Genre) {
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        movies.append(Movie(title: clean, genre: genre))
    }
    
    func save() {
        if let data = try? JSONEncoder().encode(movies) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
    
    func load() {
        // UserDefaults: menyimpan struktur data yang ada pada aplikasi dalam format JSON
        if let data = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Movie].self, from: data) {
            movies = decoded
        } else {
            let g = Genre.all
            movies = [
                Movie(title: "The Incredibles", genre: g[0]),
                Movie(title: "Shrek 2", genre: g[1], isFavorite: true)
            ]
            save()
        }
    }
    
    var favorites: [Movie] { movies.filter { $0.isFavorite } }
}
