//
//  TaskVM.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import Foundation
import Observation
import SwiftUI

@Observable
final class TaskVM {
    var tasks: [Task] = [
        .init(title: "Beli Booster"),
        .init(title: "Beli Celana Baru", isCompleted: true)
    ]
    
    func add(_ title: String) {
        // hapus spasi di depan atau di belakang
        let clean = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if clean.isEmpty { return }
        // append: menambahkan objek ke dalam array
        // init: memanggil apa yang mau dimasukkan ke dalam array
        tasks.append(.init(title: clean))
    }
    
    func remove(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
    
    func toggle(_ task: Task) {
        // firstIndex: mengembalikan index pertama yang ditemukan
        // dimana id yang dipilih sama dengan id yang ada di dalam task
        if let idx = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[idx].isCompleted.toggle()
        }
    }
}
