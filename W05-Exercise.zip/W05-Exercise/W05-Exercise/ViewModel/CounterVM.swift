//
//  CounterVM.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

// view model merupakan source of code dari view
// variabel diletakkan disini, perubahan variabel dilakukan disini

import Foundation
import SwiftUI

@Observable // bisa dibaca dan digunakan dimanapun ketika dipanggil (public class)
final class CounterVM {
    var count: Int = 0
    var isEven: Bool { count % 2 == 0 }
    
    func increment() {
        count += 1
    }
    
    func decrement() {
        count -= 1
    }
    
    func reset() {
        count = 0
    }
}
