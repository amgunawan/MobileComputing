//
//  TaskListView.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import SwiftUI

struct TaskListView: View {
    @State private var vm = TaskVM()
    @State private var newTask = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    TextField("New Task", text: $newTask)
                        .textFieldStyle(.roundedBorder)
                    
                    Button("Add") {
                        vm.add(newTask)
                        newTask = ""
                    }
                    .buttonStyle(.borderedProminent)
                    // mencegah agar tidak bisa menambahkan task yang kosong
                    .disabled(newTask
                        .trimmingCharacters(in: .whitespaces)
                        .isEmpty)
                }
                .padding()
                
                List {
                    ForEach(vm.tasks) { task in
                        HStack {
                            Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "checkmark.circle")
                                .foregroundStyle(task.isCompleted ? .blue : .secondary)
                                .onTapGesture {
                                    vm.toggle(task)
                                }
                            Text(task.title)
                                .strikethrough(task.isCompleted)
                        }
                    }
                    .onDelete(perform: vm.remove)
                }
                .listStyle(.inset)
            }
        }
        .navigationTitle("😒 Tasks")
        .toolbar {
            EditButton()
        }
        .padding()
    }
}

#Preview {
    TaskListView()
}
