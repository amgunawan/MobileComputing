//
//  Movie.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import Foundation

struct Movie: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var genre: Genre // linked model
    var isFavorite: Bool = false
}
