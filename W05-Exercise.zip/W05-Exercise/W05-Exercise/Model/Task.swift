//
//  Task.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

// coding structural biasanya diawali dengan pembuatan model terlebih dahulu
// model bisa disebut sebagai database structure

import Foundation

// contoh pembuatan sebuah model

// identifiable: who's who
// codable: struct bisa berkomunikasi dengan file lain atau API
// hashable: Swift bisa melakukan komparasi atau track code
struct Task: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var isCompleted: Bool = false // ketika ada objek baru di dalam class, maka default value = false
}

// untuk setiap Task akan memiliki identifier atau ID yang unik
// identifier bisa menggunakan atribut bebas yang ada di struct (tidak harus .id)
// identifier sama dengan primary key
