//
//  Genre.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import Foundation

struct Genre: Identifiable, Codable, Hashable {
    let id: UUID = UUID()
    var name: String
    var colorHex: String
    
    static let all: [Genre] = [
        .init(name: "Action", colorHex: "#3265a8"),
        .init(name: "Romance", colorHex: "#a8327b")
    ]
}
