//
//  W05_ExerciseApp.swift
//  W05-Exercise
//
//  Created by student on 09/10/25.
//

import SwiftUI

@main
struct W05_ExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            MovieHomeView()
        }
    }
}
