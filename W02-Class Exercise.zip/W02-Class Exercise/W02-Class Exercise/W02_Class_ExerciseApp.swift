//
//  W02_Class_ExerciseApp.swift
//  W02-Class Exercise
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_Class_ExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
