//
//  ContentView.swift
//  W02-Class Exercise
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        // Container, di dalam setiap container ada banyak komponen
        // Penambahan komponen yang ada di dalam VStack akan turun penambahannya
        VStack(
            // .leading: rata kiri, .center: rata tengah, .trailing: rata kanan
            alignment: .center,
            // fungsi: memberi jarak untuk setiap item pada VStack (dalam px)
            spacing: 8
        ) {
            Text("Angela Melia Gunawan")
            Text("Ponorogo")
            // fungsi: memberi jarak dan memenuhi ukuran layar (container)
            Spacer()
            Text("Angela")
            Spacer()
            
            // 1...10: 1 hingga 10
            // 1..<10: 1 hingga lebih kecil dari 10
            ForEach(1...10, id: \.self) {
                // $0: id di dalam for yang merupakan indeks ke-0
                Text("Hello, World! \($0)")
            }
        }
        .padding()
        .background(Color.cyan.opacity(0.5))
        
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(.pink)
                .frame(width: 200, height: 125)
            
            // jika teks dipindah ke bagian atas sebelum rounded rectangle
            // maka teks tertutup dengan rounded rectangle & tidak ditampilkan
            Text("Hello World")
                .foregroundColor(.white)
                .font(.headline)
            
            Circle()
                .frame(width:50, height: 50)
                // diberi opacity agar teks tidak tertutup
                .opacity(0.2)
        }
    }
}

#Preview {
    ContentView()
}
