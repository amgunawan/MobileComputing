//
//  MovieCardView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCardView: View {
    let movie: Movie
    
    var body: some View {
        NavigationLink(destination: MovieDetailView(movie: movie)) {
            VStack(alignment: .leading) {
                AsyncImage(url: URL(string: movie.imageUrl)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 200)
                            .cornerRadius(10)
                    case .failure:
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.gray)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    @unknown default:
                        EmptyView()
                    }
                }
                
                Text(movie.title)
                    .font(.headline)
                    .lineLimit(1)
                    .padding(.top, 5)
                    .foregroundColor(.black)
                
                Text("\(movie.genre) • \(movie.year)")
                    .font(.subheadline)
                    .foregroundColor(.black)
            }
            .padding()
            .background(.black.opacity(0.1))
            .cornerRadius(15)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
    }
}
