//
//  MovieCardView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCardView: View {
    let movie: Movie
    
    var body: some View {
        NavigationLink(destination: MovieDetailView(movie: movie)) {
            VStack(alignment: .leading, spacing: 5) {
                AsyncImage(url: URL(string: movie.imageUrl)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(height: 200)
                            .cornerRadius(10)
                    case .failure:
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.gray)
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(10)
                    @unknown default:
                        EmptyView()
                    }
                }
                
                Text(movie.title)
                    .font(.headline)
                    .lineLimit(1)
                    .padding(.top, 5)
                    .foregroundColor(.white)
                
                HStack(spacing: 4) {
                    Image(systemName: "star.fill")
                        .foregroundColor(.yellow)
                        .font(.caption)
                    Text(String(format: "%.1f/10", movie.rating))
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                
                Text(movie.description)
                    .multilineTextAlignment(.leading)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .lineLimit(2)
                    .padding(.bottom)
                
                Text("\(movie.genre) • \(movie.year)")
                    .font(.subheadline)
                    .foregroundColor(.white)
            }
            .padding()
            .background(.white.opacity(0.1))
            .cornerRadius(15)
            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        }
    }
}
