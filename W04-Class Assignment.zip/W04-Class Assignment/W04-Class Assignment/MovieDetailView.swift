//
//  MovieDetailView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 5) {
                HStack{
                    Spacer()
                    AsyncImage(url: URL(string: movie.imageUrl)) { phase in
                        switch phase {
                        case .empty:
                            ProgressView()
                                .frame(width: 200, height: 300)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                                .padding(.bottom)
                        case .success(let image):
                            image
                                .resizable()
                                .scaledToFit()
                                .frame(height: 300)
                                .cornerRadius(10)
                                .padding(.bottom)
                        case .failure:
                            Image(systemName: "photo")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200, height: 300)
                                .foregroundColor(.gray)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(10)
                                .padding(.bottom)
                        @unknown default:
                            EmptyView()
                        }
                    }
                    Spacer()
                }
                
                Text(movie.title)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("\(movie.genre) • \(movie.year)")
                    .font(.subheadline)
                    .foregroundColor(.white)
                
                Text("\(movie.description)")
                    .font(.body)
                    .foregroundColor(.white)
                    .padding()
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(Color.black, for: .navigationBar)  
        .toolbarBackground(.visible, for: .navigationBar)
        .toolbarColorScheme(.dark, for: .navigationBar)
        .background(Color.black)
    }
}
