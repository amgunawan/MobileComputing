//
//  MovieDetailView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                AsyncImage(url: URL(string: movie.imageUrl)) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                            .frame(height: 300)
                            .frame(maxWidth: .infinity)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(height: 300)
                            .cornerRadius(10)
                    case .failure:
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 300)
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.gray)
                            .background(Color.gray.opacity(0.3))
                            .cornerRadius(10)
                    @unknown default:
                        EmptyView()
                    }
                }
                .frame(width: 250, height:300)
                
                Text(movie.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                
                Text(movie.genre)
                    .font(.title3)
                    .foregroundColor(.black)
                
                Text("Release Year: \(movie.year)")
                    .font(.subheadline)
                    .foregroundColor(.black)
                
                Text("Description: \(movie.description)")
                    .font(.body)
                    .foregroundColor(.black)
                    .padding(.top)
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
