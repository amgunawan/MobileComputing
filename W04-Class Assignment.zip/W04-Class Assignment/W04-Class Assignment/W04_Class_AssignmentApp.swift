//
//  W04_Class_AssignmentApp.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_Class_AssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
