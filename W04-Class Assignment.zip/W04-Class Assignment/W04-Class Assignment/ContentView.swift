//
//  ContentView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let year: String
    let imageUrl: String
    let description: String
    let rating: Double
}

struct ContentView: View {
    let movies = [
        Movie(title: "Black Panther", genre: "Sci-Fi", year: "2018", imageUrl: "https://image.tmdb.org/t/p/original/uxzzxijgPIY7slzFvMotPv8wjKA.jpg", description: "T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future and must confront a challenger from his country's past.", rating: 7.3),
        Movie(title: "The Fantastic Four: First Steps", genre: "Action", year: "2025", imageUrl: "https://image.tmdb.org/t/p/original/abqOz6EL3yXyOOafCPZxjL1M5bQ.jpg", description: "Forced to balance their roles as heroes with the strength of their family bond, the Fantastic Four must defend Earth from a ravenous space god called Galactus and his enigmatic herald, the Silver Surfer.", rating: 8.1),
        Movie(title: "The Dark Knight", genre: "Action", year: "2008", imageUrl: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg", description: "When a menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman, James Gordon and Harvey Dent must work together to put an end to the madness.", rating: 9.0),
        Movie(title: "Avengers: Endgame", genre: "Superhero", year: "2019", imageUrl: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg", description: "After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos' actions and restore balance to the universe.", rating: 8.4),
        Movie(title: "Parasite", genre: "Thriller", year: "2019", imageUrl: "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg", description: "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.", rating: 8.6),
        Movie(
            title: "Inception", genre: "Sci-Fi", year: "2010", imageUrl: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg", description: "A thief who enters the dreams of others to steal secrets from their subconscious must complete his toughest job yet: planting an idea into someone’s mind.", rating: 8.8
        )
    ]
    
    @State private var searchText = ""
    @State private var isLoading = true
    @State private var animateLogo = false
    @State private var currentIndex = 0
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return movies
        } else {
            return movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var timer = Timer.publish(every: 5, on: .main, in: .common).autoconnect()
    
    var body: some View {
        NavigationStack {
            ZStack {
                if !isLoading {
                    VStack (alignment: .leading, spacing: 20) {
                        HStack (alignment: .center, spacing: 20) {
                            SearchBar(text: $searchText)
    
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 35, height: 35)
                                .foregroundColor(.white)
                        }

                        ScrollView {
                            TabView(selection: $currentIndex) {
                                ForEach(0..<movies.count, id: \.self) { index in
                                    AsyncImage(url: URL(string: movies[index].imageUrl)) { image in
                                        image
                                            .resizable()
                                            .scaledToFill()
                                    } placeholder: {
                                        ProgressView()
                                    }
                                    .tag(index)
                                    .frame(height: 220)
                                    .clipped()
                                    .cornerRadius(12)
                                }
                            }
                            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
                            .frame(height: 240)
                            .onReceive(timer) { _ in
                                withAnimation {
                                    currentIndex = (currentIndex + 1) % movies.count
                                }
                            }
                            
                            HStack {
                                Image(systemName: "movieclapper.fill")
                                
                                Text("Trending Now")
                                    .font(.title2)
                                    .fontWeight(.semibold)
                                
                                Spacer()
                            }
                            .foregroundColor(.white)
                            
                            Spacer()
    
                            if filteredMovies.isEmpty {
                                Text("No movie found.")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.top, 180)
                                    .frame(maxWidth: .infinity, alignment: .center)
                            } else {
                                LazyVGrid(columns: columns, spacing: 20) {
                                    ForEach(filteredMovies) { movie in
                                        MovieCardView(movie: movie)
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                    .background(Color.black)
                }
                
                if isLoading {
                    ZStack {
                        Color.black.ignoresSafeArea()
                        
                        ZStack {
                            Circle()
                                .fill(Color.red.opacity(0.6))
                                .frame(width: 250, height: 250)
                                .scaleEffect(animateLogo ? 1.2 : 0.8)
                                .blur(radius: 80)
                                .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: animateLogo)
                            
                            Text("UCFlix")
                                .font(.system(size: 48, weight: .bold))
                                .foregroundColor(.red)
                                .scaleEffect(animateLogo ? 1 : 0.7)
                                .opacity(animateLogo ? 1 : 0)
                                .animation(.easeInOut(duration: 1), value: animateLogo)
                        }
                    }
                    .onAppear {
                        animateLogo = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            withAnimation {
                                isLoading = false
                            }
                        }
                    }
                }
            }
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        TextField("Search movies...", text: $text)
            .padding(10)
            .background(Color.gray.opacity(0.1))
            .foregroundStyle(Color.white)
            .cornerRadius(8)
            .autocapitalization(.none)
            .disableAutocorrection(true)
    }
}

#Preview {
    ContentView()
}
