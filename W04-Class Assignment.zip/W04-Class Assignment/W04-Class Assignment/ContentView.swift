//
//  ContentView.swift
//  W04-Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let year: String
    let imageUrl: String
    let description: String
}

struct ContentView: View {
    let movies = [
        Movie(title: "Black Panther", genre: "Sci-Fi", year: "2018", imageUrl: "https://image.tmdb.org/t/p/original/uxzzxijgPIY7slzFvMotPv8wjKA.jpg", description: "T'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future and must confront a challenger from his country's past."),
        Movie(title: "The Fantastic Four: First Steps", genre: "Action", year: "2025", imageUrl: "https://image.tmdb.org/t/p/original/abqOz6EL3yXyOOafCPZxjL1M5bQ.jpg", description: "Forced to balance their roles as heroes with the strength of their family bond, the Fantastic Four must defend Earth from a ravenous space god called Galactus and his enigmatic herald, the Silver Surfer."),
        Movie(title: "The Dark Knight", genre: "Action", year: "2008", imageUrl: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg", description: "When a menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman, James Gordon and Harvey Dent must work together to put an end to the madness."),
        Movie(title: "Avengers: Endgame", genre: "Superhero", year: "2019", imageUrl: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg", description: "After the devastating events of Avengers: Infinity War (2018), the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos' actions and restore balance to the universe."),
        Movie(title: "Parasite", genre: "Thriller", year: "2019", imageUrl: "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg", description: "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.")
    ]
    
    @State private var searchText = ""
    @State private var isLoading = true

    var filteredMovies: [Movie] {
        if searchText.isEmpty {
            return movies
        } else {
            return movies.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }

    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                if !isLoading {
                    VStack {
                        SearchBar(text: $searchText)
                            .padding(.top)

                        ScrollView {
                            LazyVGrid(columns: columns, spacing: 20) {
                                ForEach(filteredMovies) { movie in
                                    MovieCardView(movie: movie)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    .background(.white)
                    .navigationTitle("UCFlix")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .principal) {
                            VStack {
                                Text("UCFlix")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                Text("Dive Into Films, Uncover the Details.")
                                    .font(.caption)
                            }
                        }
                    }
                }
                
                if isLoading {
                    VStack {
                        Text("UCFlix")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .scaleEffect(isLoading ? 1.1 : 1)
                            .opacity(isLoading ? 1 : 0)
                            .animation(.easeInOut(duration: 1).repeatForever(autoreverses: true), value: isLoading)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity) // Fills the screen
                    .background(
                        LinearGradient(gradient: Gradient(colors: [Color.black, Color.red]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                isLoading = false
                            }
                        }
                    }
                }
            }
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        TextField("Search movies...", text: $text)
            .padding(10)
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
            .padding(.horizontal)
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .padding(.top, 10)
    }
}

#Preview {
    ContentView()
}
