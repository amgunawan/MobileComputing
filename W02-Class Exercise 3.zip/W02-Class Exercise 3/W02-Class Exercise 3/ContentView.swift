//
//  ContentView.swift
//  W02-Class Exercise 3
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    // deklarasi variabel
    @State private var point = 80
    
    // default sintaks function yang hasilnya view
    private func actionButton(_ title: String, action: @escaping() -> Void) -> some View {
        Button(title, action: action)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .foregroundColor(.white)
            .background(.blue)
            .cornerRadius(10)
    }
    
    private func progressCard(score: Int) -> some View {
        VStack() {
            Text("Current Score").font(.headline)
            ProgressView(value: Double(score),
                         total:100)
            Text("\(score)/100")
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.green.opacity(0.3))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }
    
    var body: some View {
        VStack {
            progressCard(score: point)
            HStack {
                actionButton("Add 10") {
                    point += 10
                }
                actionButton("Reset") {
                    point = 0
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
