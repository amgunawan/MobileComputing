//
//  W02_Class_Exercise_3App.swift
//  W02-Class Exercise 3
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_Class_Exercise_3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
