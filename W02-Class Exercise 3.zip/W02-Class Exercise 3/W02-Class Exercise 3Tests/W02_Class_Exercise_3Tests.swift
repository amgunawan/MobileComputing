//
//  W02_Class_Exercise_3Tests.swift
//  W02-Class Exercise 3Tests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Class_Exercise_3

struct W02_Class_Exercise_3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
