//
//  W02_Class_Exercise_2App.swift
//  W02-Class Exercise 2
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_Class_Exercise_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
