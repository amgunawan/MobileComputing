//
//  ContentView.swift
//  W02-Class Exercise 2
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    // Deklarasi variabel untuk toggle
    @State private var isOn: Bool = false
    
    @State private var volume: Double = 0.5
    @State private var name : String = ""
    
    let fruits = ["Apple", "Orange", "Banana"]
    
    var body: some View {
        // identifier: pengenal untuk setiap objek di list
        List(fruits, id: \.self) { fruit in
            HStack {
                Text(fruit)
                Spacer()
                Text("u u a a")
            }
        }
        
        VStack {
            Button("Sign In")
            {
                print("Berhasil Sign In")
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, maxHeight: 40)
            .background(.blue)
            .cornerRadius(30)
            
            Button("Sign Up")
            {
                print("Berhasil Sign Up")
            }
            .foregroundColor(.blue)
            .frame(maxWidth: .infinity, maxHeight: 40)
            .overlay(RoundedRectangle(cornerRadius: 30)
                .stroke(.blue, lineWidth: 1))
            
            .padding(.bottom, 20)
            
            Button("Delete Account")
            {
                print("Berhasil Delete Account")
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, maxHeight: 40)
            .background(.red)
            .cornerRadius(30)
            
            .padding(.bottom, 20)
            
            Button("Default Button Apple")
            {
                print("Mantap sesuai HIG")
            }
            .buttonStyle(.bordered)
            .tint(.blue)
            
            Image(systemName: "trash.fill")
                .font(.system(size: 50))
                .symbolRenderingMode(.multicolor)
            
            // isOn: binding variable yang merupakan bagian dari toggle yang memberitahu toggle on/off
            Toggle("Enable Notifications", isOn: $isOn)
                .padding()
            Text( isOn ? "Hore" : "Yah")
            
            Slider(value: $volume, in: 0...1)
            Text("Volume sekarang: \(volume, specifier: "%.2f")")
            
            // Nama Anda: placeholder
            TextField("Nama Anda", text: $name)
                .textFieldStyle(.roundedBorder)
                .padding()
            Text(name == "" ? "" : "Halo, \(name)!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
