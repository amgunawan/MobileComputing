//
//  W02_Class_Exercise_2Tests.swift
//  W02-Class Exercise 2Tests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Class_Exercise_2

struct W02_Class_Exercise_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
