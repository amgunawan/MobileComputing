//
//  W02_Class_PracticeTests.swift
//  W02-Class PracticeTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_Class_Practice

struct W02_Class_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
