//
//  ContentView.swift
//  W02-Class Practice
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(.cyan)
                .opacity(0.5)
                .frame(width: 200, height: 125)
            
            HStack() {
                Text("Angela")
                    .padding(.trailing, 20)
                VStack {
                    Text("❤️")
                    HStack {
                        Text("🍎")
                        Text("🍌")
                    }
                }
            }
        }
        
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(.cyan)
                .opacity(0.5)
                .frame(width: 200, height: 125)
            
            HStack() {
                Text("Angela")
                    .padding(.bottom, 90)
                    .padding(.trailing, 60)
                VStack {
                    Text("❤️")
                    HStack {
                        Text("🍎")
                        Text("🍌")
                    }
                }
                .padding(.top, 60)
            }
        }
        
        VStack {
            Text("Halo, aku Angela")
                .padding(.horizontal, 10)
                // width, height: value konstan yang pasti & tidak berubah-ubah
                // maxWidth, maxHeight: value lebar maksimum, sehingga bisa berubah-ubah
                .frame(maxWidth: .infinity)
                .background(.purple)
                .padding(10)
                .background(.teal)
        }
        .padding()
        
        VStack {
            Text("Shadow Example")
                .foregroundColor(.white)
                .padding()
                .background(.brown)
                .cornerRadius(10)
                .shadow(color: .yellow, radius: 5, x:2, y:2)
        }
    }
}

#Preview {
    ContentView()
}
