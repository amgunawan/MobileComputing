//
//  ContentView.swift
//  W01-Class Exercise
//
//  Created by student on 11/09/25.
//

import SwiftUI

// jika ingin mendeklarasikan variabel, lebih baik buat struct baru
// struct mirip dengna class
struct Student {
    var name: String
    var year: Int
    func display() -> String {
        "\(name), \(year)"
    }
}

enum UserStatus {case offline, online, busy}

struct ContentView: View {
    // jika ingin mendeklarasikan variabel di dalam view, harus ada di luar body
    let userName = "Angela"
    let scores = [95, 92, 100]
    let student = Student(name: "Jessica", year: 2)
    let status: UserStatus = .online
    
    var badge: String {
        // badge akan otomatis terisi ketika scores menemui kondisi dimana:
        // jika value yang dihasilkan lebih besar dari 85, maka hasilnya akan centang, sisanya silang
        scores.allSatisfy { $0 >= 85} ? "✅" : "❌"
    }
    
    var body: some View {
        VStack(spacing: 10) {
            Text("Hello, \(userName)")
                .font(.title)
            
            Text("Student: \(student.display())")
            
            // jika status adalah online, tampilkan Online, sisanya tampilkan Offline
            Text("Status: \(status == .online ? "🟢 Online" : "🔴 Offline")")
            // tanda tanya 1 maka ada true/false
            // tanda tanya 2 maka ada jawaban opsional
            
            Text("Badge: \(badge)")
                .padding(.bottom, 25)
        }
        
        VStack(alignment: .center, spacing: 15) {
            // setiap objek di dalam HStack akan ke kanan
            HStack(spacing: 12) {
                Text("Angela")
                Text("Melia")
                Text("Gunawan")
            }
            
            // 3 buah VStack di dalam 1 HStack
            // di dalam setiap VStack, ada emoji yang berbeda
            HStack(spacing: 12) {
                VStack() {
                    Text("❤️")
                    Text("🙈")
                    Text("👀")
                }
                VStack() {
                    Text("💕")
                    Text("😂")
                    Text("👋")
                }
                VStack() {
                    Text("😳")
                    Text("💁")
                    Text("😴")
                }
            }
        }
        
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
                .padding()
            
            Text("Hello, World!")
                // modifier teks: font, font weight, padding, dll
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.horizontal)
            
            Text("Declarative UI | Live Preview | SwiftUI Cool!")
                .multilineTextAlignment(.center)
                .padding()
                .font(.headline)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                // mengubah warna teks
                .foregroundColor(.blue)
            
            Image(systemName: "sparkles")
                // mengubah warna image menjadi gradient
                .foregroundStyle(LinearGradient(colors: [.yellow, .pink], startPoint: .topLeading, endPoint: .bottomTrailing))
                .imageScale(.large)
                .font(.system(size:100))
                .padding()
                .overlay(content: {
                    Circle().strokeBorder(.gray.opacity(0.3),lineWidth: 2)
                })
            
            Text("👋")
        }
        .padding()
    }
    let name = "Alice"
    var age = 20
    //function berada di luar view, di dalam view tidak boleh ada function
    func greet() {
        print("Hello, \(name), age \(age)")
    }
    
}

#Preview {
    ContentView()
}
