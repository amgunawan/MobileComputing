//
//  W01_Class_ExerciseApp.swift
//  W01-Class Exercise
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_Class_ExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
