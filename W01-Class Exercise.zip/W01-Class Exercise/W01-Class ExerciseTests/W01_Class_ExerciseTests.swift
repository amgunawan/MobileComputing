//
//  W01_Class_ExerciseTests.swift
//  W01-Class ExerciseTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_Class_Exercise

struct W01_Class_ExerciseTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
